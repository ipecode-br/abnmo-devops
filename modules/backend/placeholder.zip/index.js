exports.handler = async (event) => {
    console.log('Event:', JSON.stringify(event, null, 2));
    
    return {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'GET,HEAD,OPTIONS,POST,PUT'
        },
        body: JSON.stringify({
            message: "Placeholder function",
            requestId: event.requestContext ? event.requestContext.requestId : 'direct-invocation',
            path: event.path || '/',
            httpMethod: event.httpMethod || 'unknown'
        }),
    };
};
